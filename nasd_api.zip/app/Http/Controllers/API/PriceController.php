<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PriceController extends Controller
{
    public function prices_vfd()
    {



        $api_url = 'https://www.nasddatax.com/api/equity/ticker/update';
        $json_data = file_get_contents($api_url);



          $response_data = json_decode($json_data);
            $live_trades = $response_data;

            $security_name = "";
            $security_price = "";


            foreach ($live_trades as $trades) :
                if($trades->security == "SDVFDGROUP")
                {

                     $security_name = $trades->security;
                     $security_price = $trades->closeprice;
                }

            endforeach;

            $data = [
                'Security' => $security_name,
                'Price' => $security_price
            ];

          return  response()->json([
                    'status' => 200,
                     'Ticker' => $data
                        ]);

    }

}
